﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misol
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "mo'minjon";
            Console.WriteLine(metod2(a));
            Console.ReadKey();
        }
        static string metod(string a)
        {   
            string S = "";
            for (int i = 0; i < a.Length; i++)
            {
                S += a[i]+": ";
                for (char j=(char)0; j<=(char)255; j++)
                {
                    if (a[i] == j) { S +=  (int)j+", "; }
                }
            }
            return S;
        }
        static string metod2(string a) {
            string S = "";
            string tek = " ";
            for (int i = 0; i < a.Length; i++)
            {   
                int n2 = 0;
                for (int k = 0; k <tek.Length; k++)
                {
                    if (a[i] == tek[k]) { n2++; }
                }
                if (n2==0) {
                    S = S+a[i] + ": ";
                    int n = 0;
                    for (int j = 0; j < a.Length; j++)
                    {
                        if (a[i] == a[j]) { n++; }
                    }
                    tek += a[i];
                    S =S+ n + ", ";
                }
            }
            return S;
        }
    }
}

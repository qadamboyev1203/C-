﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MehhodExtansion
{
    public class Mathh
    {
        public int Summ(int a, int b)
        {
            return a + b;
        }
    }
}

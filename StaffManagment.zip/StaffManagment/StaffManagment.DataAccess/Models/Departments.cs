﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StaffManagment.Models
{
    public enum Departments
    {
        None,
        Admin,
        HR,
        Production,
        RnD,
        Sales,
        Marketing
    }
}

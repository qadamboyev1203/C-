﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StaffManagment.Models
{
    public class MockStaffRepository : IStaffRepository
    {
        private List<Staff> _staffs = null;
        public MockStaffRepository()
        {
            _staffs = new List<Staff>()
            {
                new Staff(){ Id=1, FirstName="Mominjon1", LastName="Qadamboyev", Email="qadamboyevmominjon1203@gmail.com", Department=Departments.Admin},
                 new Staff(){ Id=2, FirstName="Mominjon2", LastName="Qadamboyev", Email="qadamboyevmominjon08@gmail.com", Department=Departments.Production},
                  new Staff(){ Id=3, FirstName="Mominjon3", LastName="Qadamboyev", Email="qadamboyevmominjon1812@gmail.com", Department=Departments.RnD}
            };
        }

        public Staff Create(Staff staff)
        {
            staff.Id = _staffs.Max(s => s.Id) + 1;
            _staffs.Add(staff);
            return staff;
        }

        public Staff Delete(int id)
        {
            var staff = _staffs.FirstOrDefault(s => s.Id.Equals(id));
            if (staff != null)
            {
                _staffs.Remove(staff);
            }
            return staff;
        }

        public Staff Get(int id)
        {
            return _staffs.FirstOrDefault(staff => staff.Id.Equals(id));
        }

        public IEnumerable<Staff> GetAll()
        {
            return _staffs;
        }

        public Staff Update(Staff updatedstaff)
        {
            var staff = _staffs.FirstOrDefault(s => s.Id.Equals(updatedstaff.Id));
            if (staff != null)
            {
                staff.FirstName = updatedstaff.FirstName;
                staff.LastName = updatedstaff.LastName;
                staff.Email = updatedstaff.Email;
                staff.Department = updatedstaff.Department;
            }
            return staff;
        }
    }
}
